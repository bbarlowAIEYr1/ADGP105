#pragma once
#include <iostream> //c++ lib.
#include <string> //c++ lib.
#include "Cell.h" //header file

//Player class: holds position for player (public)
//Has a default constructor
class Player //player class
{
public: //public data
	Cell position; //used for grid position

	Player() //default constructor
	{

	}
};